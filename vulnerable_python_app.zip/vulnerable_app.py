import subprocess
import sqlite3
from flask import Flask, request

app = Flask(__name__)

# 1️⃣ Command injection (unsafe)
@app.route("/run")
def run_command():
    cmd = request.args.get("cmd")
    output = subprocess.getoutput(cmd)  # Vulnerable!
    return f"<pre>{output}</pre>"

# 2️⃣ SQL Injection (unsafe)
@app.route("/user")
def get_user():
    user_id = request.args.get("id")
    conn = sqlite3.connect("test.db")
    cur = conn.cursor()
    query = f"SELECT * FROM users WHERE id={user_id}"  # Vulnerable!
    cur.execute(query)
    result = cur.fetchall()
    conn.close()
    return str(result)

if __name__ == "__main__":
    app.run(debug=True)
